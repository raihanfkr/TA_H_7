package apap.ta.sipelatihan.rest;

public class Setting {
    final public static String laporanUrl = "https://88335515-8e94-4a12-9138-f015a2f19645.mock.pstmn.io";
    final public static String APIsipegawai = "https://si-pegawai.herokuapp.com";
}
