package apap.ta.sipelatihan.service;

import apap.ta.sipelatihan.model.UserModel;
import apap.ta.sipelatihan.repository.UserDb;
import apap.ta.sipelatihan.rest.Setting;
import com.fasterxml.jackson.databind.util.TypeKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ReactiveHttpOutputMessage;
import org.springframework.http.client.reactive.ClientHttpRequest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.transaction.Transactional;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
@Transactional
public class UserServiceImpl implements UserService{
    private final WebClient webClient;

    public UserServiceImpl(WebClient.Builder webClientBuilder){
        this.webClient = webClientBuilder.baseUrl(Setting.sipegawaiUrl)
//                                        .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
                .build();
    }

    @Autowired
    private UserDb userDB;

    @Override
    public UserModel addUser(UserModel user) {
        String pass = encrypt(user.getPassword());
        user.setPassword(pass);

        return userDB.save(user);
    }

    @Override
    public String encrypt(String password) {
        String hashedPassword = new BCryptPasswordEncoder().encode(password);
        return hashedPassword;
    }

    @Override
    public UserModel findUser(String user) {
        return userDB.findByUsername(user);
    }

    @Override
    public boolean checkPassword(String password) {
        boolean atleastOneAlpha = password.matches(".*[a-zA-Z]+.*");
        boolean atleastOneNumber = password.matches(".*[0-9]+.*");
        boolean atleastEightChar = password.length() >= 8;
        return atleastOneAlpha && atleastOneNumber && atleastEightChar;
    }

    @Override
    public UserModel findUserById(String id) {
        return userDB.findByUuid(id);
    }

    @Override
    public Mono<String> postPegawai(UserModel user,
                                    String nama,
                                    String noTelepon,
                                    String tempatLahir,
                                    String alamat,
                                    String tanggalLahir) {

        Map<String, String> data = new HashMap<>();
        data.put("username", user.getUsername());
        data.put("nama", nama);
        data.put("noTelepon", noTelepon);
        data.put("tempatLahir", tempatLahir);
        data.put("tanggalLahir", tanggalLahir);
        data.put("alamat",alamat);
        data.put("roleId", Long.toString(user.getRole().getId_role()));

        return this.webClient.post().uri("/api/v1/pegawai")
//                .contentType(MediaType.APPLICATION_JSON)
                .syncBody(data)
                .retrieve()
                .bodyToMono(String.class);
    }

    @Override
    public Mono<String> testPostPegawai() {

        Map<String, String> data = new HashMap<>();
        data.put("username", "akugamauapap");
        data.put("nama", "halo hai hore");
        data.put("noTelepon", "08000009900");
        data.put("tempatLahir", "Jakarta");
        data.put("tanggalLahir", "2000-01-11T13:00");
        data.put("alamat", "Jl Satu Nusa Satu Bangsa");
        data.put("roleId", "1");

        return this.webClient.post().uri("/api/v1/pegawai")
//                .contentType(MediaType.APPLICATION_JSON)
                .syncBody(data)
                .retrieve()
                .bodyToMono(String.class);
    }
}
