package apap.ta.sipelatihan.controller;

import apap.ta.sipelatihan.model.RoleModel;
import apap.ta.sipelatihan.model.UserModel;
import apap.ta.sipelatihan.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import javax.servlet.http.HttpServletRequest;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserController {
    @Autowired
    private UserService userService;

    @Autowired
    private RoleService roleService;

    @GetMapping(value = "/add")
    private  String addUserForm(Model model){
        UserModel user = new UserModel();
        List<RoleModel> listRole = roleService.findAll();

        model.addAttribute("user", user);
        model.addAttribute("listRole", listRole);

        return "form-pendaftaran-user";
    }

    @PostMapping(value = "/add")
    private String addUserSubmit(
            @ModelAttribute UserModel user,
            @RequestParam("nama") String nama,
            @RequestParam("noTelepon") String noTelepon,
            @RequestParam("tempatLahir") String tempatLahir,
            @RequestParam("tanggalLahir") String tanggalLahir,
            @RequestParam("alamat") String alamat,
            Model model) {
        if(userService.checkPassword(user.getPassword()) == true){
            UserModel addedUser = userService.addUser(user);
            model.addAttribute("user", addedUser);
            model.addAttribute("berhasil", "User berhasil ditambahkan");
            model.addAttribute("noTelepon", noTelepon);
            model.addAttribute("nama", nama);
            model.addAttribute("tempatLahir", tempatLahir);
            model.addAttribute("alamat", alamat);

            SimpleDateFormat readingFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm");
            SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm");

            try {
                Date date = readingFormat.parse(tanggalLahir);
                model.addAttribute("tanggalLahir", outputFormat.format(date));
            } catch (Exception e){
                System.out.println("parse failed");
            }

            Mono<String> response = userService.postPegawai(addedUser, nama, noTelepon, tempatLahir, alamat, tanggalLahir);
            System.out.println(response.block());

        }else{
            model.addAttribute("user", user);
            model.addAttribute("failed", "Password harus terdiri dari minimal 8 karakter yang mengandung huruf kapital, angka dan huruf kecil");
        }
        return "pendaftaran-user";
    }

    @GetMapping(value = "/test-post")
    private Mono<String> postPegawai(){
        Mono<String> response = userService.testPostPegawai();

        return response;
    }

    @GetMapping("/info-pengguna")
    public String informasiPengguna(
            @RequestParam(value = "id") HttpServletRequest request, Model model){
        UserModel user = userService.findUser(request.getUserPrincipal().getName());
        model.addAttribute("user", user);
        return "info-pengguna";
    }
}
