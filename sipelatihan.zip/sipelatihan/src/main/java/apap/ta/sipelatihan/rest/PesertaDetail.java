package apap.ta.sipelatihan.rest;

public class PesertaDetail {
}