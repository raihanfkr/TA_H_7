package apap.ta.sipelatihan.service;

import apap.ta.sipelatihan.Repository.PelatihanDb;
import apap.ta.sipelatihan.model.PelatihanModel;
import apap.ta.sipelatihan.model.TrainerModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;


@Service
@Transactional
public class PelatihanServiceImpl implements PelatihanService{
    @Autowired
    PelatihanDb pelatihanDb;

    @Override
    public List<PelatihanModel> getPelatihanList() {
        return pelatihanDb.findAllByOrderById();
    }

    @Override
    public PelatihanModel getPelatihanById(Integer id) {
        return pelatihanDb.findById(id).get();
    }

    @Override
    public void addPelatihan(PelatihanModel pelatihan) {
        pelatihanDb.save(pelatihan);
    }

    @Override
    public PelatihanModel updatePelatihan(PelatihanModel pelatihan){
        pelatihanDb.save(pelatihan);
        return pelatihan;
    }

    @Override
    public PelatihanModel updateStatusPelatihan(PelatihanModel pelatihan){
        PelatihanModel targetPelatihan = pelatihanDb.findById(pelatihan.getId()).get();
        targetPelatihan.setStatus_persetujuan(pelatihan.getStatus_persetujuan());
        targetPelatihan.setUserPenyetuju(pelatihan.getUserPenyetuju());
        pelatihanDb.save(targetPelatihan);
        return targetPelatihan;
    }

    @Override
    public void deletePelatihan(Integer id) {
        pelatihanDb.deleteById(id);
    }
}