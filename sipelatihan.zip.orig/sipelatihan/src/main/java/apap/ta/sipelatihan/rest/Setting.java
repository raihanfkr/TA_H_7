package apap.ta.sipelatihan.rest;

public class Setting {
    final public static String sipegawaiUrl = "https://si-pegawai.herokuapp.com";
}